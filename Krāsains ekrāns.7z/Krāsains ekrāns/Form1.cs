﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Krāsains_ekrāns
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void butSarkans_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
        }

        private void butOranzs_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Orange;
        }

        private void butDzeltens_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Yellow;
        }

        private void butZals_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Green;
        }

        private void butZils_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
        }
    }
}
