﻿namespace Krāsains_ekrāns
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.butSarkans = new System.Windows.Forms.Button();
            this.butOranzs = new System.Windows.Forms.Button();
            this.butDzeltens = new System.Windows.Forms.Button();
            this.butZals = new System.Windows.Forms.Button();
            this.butZils = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(8, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(362, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Klikšķini uz pogas, lai mainītu fona krāsu ...\r\n";
            // 
            // butSarkans
            // 
            this.butSarkans.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.butSarkans.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSarkans.Location = new System.Drawing.Point(12, 52);
            this.butSarkans.Name = "butSarkans";
            this.butSarkans.Size = new System.Drawing.Size(117, 41);
            this.butSarkans.TabIndex = 1;
            this.butSarkans.Text = "Sarkans";
            this.butSarkans.UseVisualStyleBackColor = false;
            this.butSarkans.Click += new System.EventHandler(this.butSarkans_Click);
            // 
            // butOranzs
            // 
            this.butOranzs.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.butOranzs.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butOranzs.Location = new System.Drawing.Point(11, 108);
            this.butOranzs.Name = "butOranzs";
            this.butOranzs.Size = new System.Drawing.Size(117, 41);
            this.butOranzs.TabIndex = 2;
            this.butOranzs.Text = "Oranžs";
            this.butOranzs.UseVisualStyleBackColor = false;
            this.butOranzs.Click += new System.EventHandler(this.butOranzs_Click);
            // 
            // butDzeltens
            // 
            this.butDzeltens.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.butDzeltens.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butDzeltens.Location = new System.Drawing.Point(12, 165);
            this.butDzeltens.Name = "butDzeltens";
            this.butDzeltens.Size = new System.Drawing.Size(117, 41);
            this.butDzeltens.TabIndex = 3;
            this.butDzeltens.Text = "Dzeltens";
            this.butDzeltens.UseVisualStyleBackColor = false;
            this.butDzeltens.Click += new System.EventHandler(this.butDzeltens_Click);
            // 
            // butZals
            // 
            this.butZals.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.butZals.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butZals.Location = new System.Drawing.Point(12, 223);
            this.butZals.Name = "butZals";
            this.butZals.Size = new System.Drawing.Size(117, 41);
            this.butZals.TabIndex = 4;
            this.butZals.Text = "Zaļš";
            this.butZals.UseVisualStyleBackColor = false;
            this.butZals.Click += new System.EventHandler(this.butZals_Click);
            // 
            // butZils
            // 
            this.butZils.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.butZils.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butZils.Location = new System.Drawing.Point(12, 285);
            this.butZils.Name = "butZils";
            this.butZils.Size = new System.Drawing.Size(117, 41);
            this.butZils.TabIndex = 5;
            this.butZils.Text = "Zils";
            this.butZils.UseVisualStyleBackColor = false;
            this.butZils.Click += new System.EventHandler(this.butZils_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 361);
            this.Controls.Add(this.butZils);
            this.Controls.Add(this.butZals);
            this.Controls.Add(this.butDzeltens);
            this.Controls.Add(this.butOranzs);
            this.Controls.Add(this.butSarkans);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Krāsains ekrāns";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button butSarkans;
        private System.Windows.Forms.Button butOranzs;
        private System.Windows.Forms.Button butDzeltens;
        private System.Windows.Forms.Button butZals;
        private System.Windows.Forms.Button butZils;
    }
}

